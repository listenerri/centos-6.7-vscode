:orphan:

CMake Release Notes
*******************

..
  This file should include the adjacent "dev.txt" file
  in development versions but not in release versions.

Releases
========

.. toctree::
   :maxdepth: 1

   3.27 <3.27>
   3.26 <3.26>
   3.25 <3.25>
   3.24 <3.24>
   3.23 <3.23>
   3.22 <3.22>
   3.21 <3.21>
   3.20 <3.20>
   3.19 <3.19>
   3.18 <3.18>
   3.17 <3.17>
   3.16 <3.16>
   3.15 <3.15>
   3.14 <3.14>
   3.13 <3.13>
   3.12 <3.12>
   3.11 <3.11>
   3.10 <3.10>
   3.9 <3.9>
   3.8 <3.8>
   3.7 <3.7>
   3.6 <3.6>
   3.5 <3.5>
   3.4 <3.4>
   3.3 <3.3>
   3.2 <3.2>
   3.1 <3.1>
   3.0 <3.0>
