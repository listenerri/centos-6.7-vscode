SOURCE_DIR
----------

.. versionadded:: 3.4

This read-only property reports the value of the
:variable:`CMAKE_CURRENT_SOURCE_DIR` variable in the directory in which
the target was defined.
