LABELS
------

Specify a list of text labels associated with a target.

Target label semantics are currently unspecified.
