LINK_FLAGS_<CONFIG>
-------------------

Per-configuration linker flags for a ``SHARED`` library, ``MODULE`` or
``EXECUTABLE`` target.

This is the configuration-specific version of :prop_tgt:`LINK_FLAGS`.

.. note::

  This property has been superseded by :prop_tgt:`LINK_OPTIONS` property.
