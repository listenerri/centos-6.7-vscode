CPACK_PERMANENT
---------------

.. versionadded:: 3.1

Request that this file not be removed on uninstall.

The property is currently only supported by the :cpack_gen:`CPack WIX Generator`.
