CPACK_NEVER_OVERWRITE
---------------------

.. versionadded:: 3.1

Request that this file not be overwritten on install or reinstall.

The property is currently only supported by the :cpack_gen:`CPack WIX Generator`.
